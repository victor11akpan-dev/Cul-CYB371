import pandas as pd

# Load the fictional student dataset
students = pd.read_csv("students.csv")

# Display the dataset
print("FICTIONAL STUDENT DATASET")
print(students.to_string(index=False))

# Display a simple summary
print("\\nAverage attendance:", students["Attendance Percentage"].mean(), "%")
print("Average examination score:", students["Average Examination Score"].mean())
