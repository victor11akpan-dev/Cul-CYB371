# Assignment Two: Fictional Student Dataset

## Description
This project contains a fictional dataset of 20 students. It was created with Python and pandas for the assignment.

## Dataset fields
- Student ID
- Department
- Level
- Attendance Percentage
- Average Examination Score

All student records and scores in this project are fictional and are for academic practice only.

## Files
- `students.csv` — the student dataset
- `main.py` — Python script that reads and displays the dataset
- `README.md` — project information

## How to run
1. Install Python.
2. Install pandas by running: `pip install pandas`
3. Keep `main.py` and `students.csv` in the same folder.
4. Run: `python main.py`
